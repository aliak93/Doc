#ifndef RECEIVER_H_OCZYMGVT
#define RECEIVER_H_OCZYMGVT

#include "core.h"

void receiver_start (void *);

#endif /* end of include guard: RECEIVER_H_OCZYMGVT */
