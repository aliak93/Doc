#ifndef SENDER_H_ZGDRAFKW
#define SENDER_H_ZGDRAFKW

#include "core.h"

void sender_start (void *);

#endif /* end of include guard: SENDER_H_ZGDRAFKW */
